import React from 'react';

const Spacer = () => {
  return <div className="py-6 md:py-8"></div>;
};

export default Spacer;
